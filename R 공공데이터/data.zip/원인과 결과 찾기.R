#### 1. 분석준비 ####
pacman::p_load(foreign,                                        # sav 파일 불러오기
               webr, ggridges, ggradar, easyalluvial, eulerr,  # 데이터의 시각화
               sjPlot, ggstatsplot,                            # 통계 관련
               caret, rsample, ranger, gbm,                    # 머신러닝 관련
               janitor, inspectdf, magrittr, tidyverse)        # 데이터 전처리

source("funs.R")


#### 2. T 검정 ####
data %>% ggbetweenstats(성별, 수학성적)


#### 3. ANOVA ####
data %>% ggbetweenstats(대학선택기준, 수학성적)


#### 4. 상관관계 ####
data %>% ggscatterstats(수학이해도, 수학성적)
data %>% ggscatterstats(수학이해도, 수학성적, point.args=list(size=2, alpha=0.01))

data %>% inspect_cor(with_col = "수학성적") %>% show_plot()


#### 4. 회귀분석 ####
#### 가. 변인통제 의미 ####
lm(수학성적~수학학습태도, data) %>% summary()          
data %>% lm_r2(수학성적~수학학습태도)

lm(수학성적~잠잔일수, data) %>% summary()              
data %>% lm_r2(수학성적~잠잔일수)

lm(수학성적~수학학습태도+잠잔일수, data) %>% summary() 
data %>% lm_r2(수학성적~수학학습태도+잠잔일수)


#### 나. 사교육의 효과성 검토 ####
data %>% lm_r2(수학성적~수학이해도)
data %>% lm_r2(수학성적~수학학습태도)
data %>% lm_r2(수학성적~수학사교육)
data %>% lm_r2(수학성적~자기주도시간)
data %>% lm_r2(수학성적~수학이해도+수학사교육)
data %>% lm_r2(수학성적~수학이해도+자기주도시간)
data %>% lm_r2(수학성적~수학이해도+수학학습태도)


#### 다. 오컴의 면도날 ####
lm(수학성적~수학이해도+수학학습태도+수학사교육+자기주도시간, data) %>% summary()  
lm(수학성적~수학이해도+수학학습태도+수학사교육+자기주도시간+
     수학흥미+초인지, data) %>% summary()
lm(수학성적~수학이해도+수학학습태도+수학사교육+자기주도시간+
     수학흥미+초인지+수학집중시간+잠잔일수+주중게임시간, data) %>% summary()


#### 라. 단계적 회귀분석 ####
lm(수학성적~수학이해도+수학학습태도+수학사교육+자기주도시간+
     수학흥미+초인지+수학집중시간+잠잔일수+주중게임시간, data) %>% 
  step()
lm(수학성적~수학이해도+수학학습태도+수학사교육+자기주도시간+
     수학흥미+초인지+수학집중시간+잠잔일수+주중게임시간, data) %>% 
  stats::step() %>% summary()


#### 마. 범주형 변수 포함 ####
data %>% lm_r2(수학성적~수학이해도+성별)
lm(수학성적~수학이해도+성별, data) %>% summary()
lm(수학성적~수학이해도+임원여부, data) %>% summary()